from django.shortcuts import render
from . models import *

from django.http import JsonResponse
from django.shortcuts import render,redirect
import pymongo
import pandas as pd
from django.contrib import messages
from datetime import datetime,timedelta
import time
def create_tutorial(request):
    # Assuming this view handles POST requests
    if request.method == 'POST':
        # Extract data from POST request
        emailid = request.POST.get('emailid')
        mobnumber = request.POST.get('mobnumber')
        username = request.POST.get('username')
        password = request.POST.get('password')


        current_d = datetime.now().date()

        business_days_to_skip = 2
        while business_days_to_skip > 0:
            current_d += timedelta(days=1)
        
            if current_d.weekday() in [5, 6]: 
                continue  
            business_days_to_skip -= 1
        one_month_after =current_d 
        new_tutorial ={"Username":username,"Full_Name":"-","Mobile_No":mobnumber,"Email Id":emailid,"BrokerName":"Demo","Create Date":str(datetime.now().date()),"Licanse":0,"Licanse Start Date":str(datetime.now().date()),"Service Start Date":str(datetime.now().date()),"Service End Date":str(one_month_after),"ServiceCount":1,"AutoLogin":""}
        inputdata={"userName":username,"password":password,"SignEmail":emailid,"SignMobileNo":mobnumber,"Create date":str(datetime.now().date()),"Status":"On"}
        
    
        UDic = {"Username":username,"Licanse Start Date":str(datetime.now().date()),"Service Start Date":str(datetime.now().date()),"Service End Date":str(one_month_after),"ServiceCount":1,"Broker":"Demo","Credit Use":0}
        
        clientkey.insert_one(UDic)
        user_collection.insert_one(new_tutorial)
        Login.insert_one(inputdata)
        messages.success(request, f'Account created for {username}!')
        return redirect('login')
    return render(request, 'signup.html',)


def Loginuser(request):
    print('...............................................................',request.method)
    if request.method == 'POST':
        # Extract data from POST request
        username = request.POST.get('username')
        password = request.POST.get('password')

        user=Login.find({"userName":username,"password":password})
        msg="Successfully Login"
        
        dic={"Username":username,"Activity":"Login","Message":msg,"System IP":"","Time":str(datetime.now().date())}
        Clientlog.insert_one(dic)
        if Login.count_documents({"userName":username,"password":password}) > 0:
            print('redirect......................................................')
            
            # return render(request,'home.html')
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    # elif request.method == 'POST':
    #     Handle GET request
    #     Perform any necessary operations for GET requests
    return render(request, 'login.html')   


def Profile(request):
    # Retrieve profile data from the database
    profile_data = user_collection.find_one({"Username": "komal"})
    mobile = profile_data["Mobile_No"]
    email = profile_data["Email Id"]
    broker = profile_data["BrokerName"]
    group = profile_data["Group"]
    
    # Initialize the count of documents
    collection_names = ["ScalpingScriptDetail", "PatternScriptDetail", "OptionScriptDetail"]
    sercount = 0
    for collection_name in collection_names:
        IPColl = db[collection_name]
        sercount += IPColl.count_documents({"Username": "komal"})

    # Get the current date as a string
    serstrdate = str(datetime.now().date())

    # Fetch client key data and calculate service count
    clientkeydf = pd.DataFrame(clientkey.find({"Username": "komal", "Service End Date": {"$gte": serstrdate}}))
    if not clientkeydf.empty:
        service = clientkeydf["ServiceCount"].sum()
    else:
        service = 1

    # For debugging: print the profile data
    print(profile_data)
    # Alternatively, to view profile data as a DataFrame (for debugging)
    print(pd.DataFrame.from_dict(profile_data, orient='index'))

    # Pass the user information to the template
    context = {
        "username": "komal",
        "mobile": mobile,
        "email": email,
        "broker": broker,
        "group": group,
        "service": service,
    }

    return render(request, 'profile.html', context)



def home(request):
    print("Request Method",request.method)
    if request.method == 'GET':
        print("Rendering home.html")
        return render(request,   'home.html',{'username': "komal"})

def addscript(request):
    if request.method == 'POST':
        exchange = request.POST.get('Exchange')
        if exchange == 'NFO':
            # Fetch data from MongoDB collection
            return("xyz")
            # nfodata = pd.DataFrame(list(NFO_Collection.objects.filter(exch='NFO').values()))
    return render(request, 'addscript.html')

def Dashboard(request): 
    if request.method == 'POST':
        exchange = request.POST.get('Exchange')
        if exchange == 'NFO':
            # Fetch data from MongoDB collection
            return("xyz")
            # nfodata = pd.DataFrame(list(NFO_Collection.objects.filter(exch='NFO').values()))Dashboard
    return render(request, 'Dashboard.html')


def Pattern(request):
    if request.method == 'POST':
        exchange = request.POST.get('Exchange')
        if exchange == 'NFO':
            # Fetch data from MongoDB collection
            return("xyz")
            # nfodata = pd.DataFrame(list(NFO_Collection.objects.filter(exch='NFO').values()))Dashboard
    return render(request, 'pattern.html')

def Description(request):
    return render(request, 'Description.html')


def Paneltrack(request):
   
    client_key_data = pd.DataFrame(Clientlog.find({"Username": "komal"},{"_id":0}))
    
    if not client_key_data.empty:
        # Rename the _id column to id
       
        client_key_data_list = client_key_data.to_dict('records')
        
        context = {'client_key_data': client_key_data_list}
       
        
        return render(request, 'Paneltrack.html', context)
    else:
        context = {'error_message': "Data not available"}
        return render(request, 'Paneltrack.html', context)
    

def logout_view(request):
    
    return redirect('login')  


def get_broker_data():
    return broker.find_one({"PanelUser": "komal"}, {"_id": 0})

def get_profile_info():
    return user_collection.find_one({"Username": "komal"}, {"_id": 0})

def brokercred(request):
    username1 = "komal"  # Replace with actual username from session or request

    profileinfo=user_collection.find_one({"Username":username1},{"_id":0})

    if profileinfo["BrokerName"] in ["Free Demo", "Demo"]:
        return render(request, 'broker_form.html', {'error_message': "Demo Account"})

    BrokerName = db["BrokerName"]
    brokerdf = get_broker_data(username1)

    if brokerdf is None:
        if request.method == 'POST':
            username = request.POST.get('username').strip()
            api_key = request.POST.get('api_key').strip()
            DOB = request.POST.get('DOB').strip()
            Pwd = request.POST.get('Pwd').strip()
            MOb = request.POST.get('MOb', '').strip()
            APIPassword = request.POST.get('APIPassword', '').strip()

            if username and api_key and DOB and Pwd:
                brokercred = {
                    "BrokerName": BrokerName,
                    "username": username,
                    "api_key": api_key,
                    "PanelUser": username1,
                    "Password": Pwd,
                    "DOB": DOB,
                    "mobileno": MOb,
                    "APIPassword": APIPassword
                }
                broker.insert_one(brokercred)
                msg = "Broker Login"
                current_datetime = datetime.now().strftime("%Y.%m.%d %H:%M:%S")
                dic = {"Username": username1, "Activity": "Broker", "Message": msg, "System IP": "", "Time": current_datetime}
                Clientlog.insert_one(dic)
                return render(request, 'broker_form.html', {'success_message': 'Data Added', 'BrokerName': BrokerName})
            else:
                return render(request, 'broker_form.html', {'error_message': "Please enter all Broker Credentials", 'BrokerName': BrokerName})
        else:
            return render(request, 'broker_form.html', {'BrokerName': BrokerName})
    else:
        context = {'error_message': "Data not available"}
        return render(request, 'broker_form.html', context)
       