from django.urls import path
from . import views 

urlpatterns = [
    path('login/', views.Loginuser, name='login'),
    path('create_tutorial/', views.create_tutorial, name='create_tutorial'),
    path('home/', views.home, name='home'),
    path('addscript/', views.addscript, name='addscript'),
    path('Dashboard/', views.Dashboard, name='Dashboard'),
    path('Pattern/', views.Pattern, name='Pattern'),
    path('Profile/', views.Profile, name='Profile'),
    path('Description/', views.Description, name='Description'),
    path('Paneltrack/', views.Paneltrack, name='Paneltrack'),
    path('logout',views.logout_view,name='logout'),
    path('brokercred/', views.brokercred, name='brokercred'),
]

# urlpatterns = [
#     # Other URL patterns...
#     path('create_tutorial/', views.create_tutorial, name='create_tutorial'),
# ]
