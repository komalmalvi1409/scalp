from django.db import models
from db_connection import db
# Create your models here.

user_collection=db["UserProfile"]
Login=db["LoginDetails"]
NFO_Collection=db["Alicetoken_NFO"]
clientkey=db["CreditManagment"] 
Clientlog=db["ClientPanelLog"]