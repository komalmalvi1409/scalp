
import pymongo

client= pymongo.MongoClient("mongodb://localhost:27017")
db=client['MongoTest']


collection=db["BrokerName"]
collection.insert_one({"BrokerName":"Mandot"})
collection.insert_one({"BrokerName":"Zebull"})
collection.insert_one({"BrokerName":"Aliceblue"})
collection.insert_one({"BrokerName":"Free Demo"})
collection.insert_one({"BrokerName":"Demo"})
collection.insert_one({"BrokerName":"Indira Securities"})
collection.insert_one({"BrokerName":"ICICI"})
collection.insert_one({"BrokerName":"Angel"})
collection.insert_one({"BrokerName":"Upstox"})
collection.insert_one({"BrokerName":"KOTAK"})
collection.insert_one({"BrokerName":"DHAN"})
collection.insert_one({"BrokerName":"5Paisa"})
collection.insert_one({"BrokerName":"Fyers"})

collection=db["PatternName"]
collection.insert_one({"PWay":"CandleStick","PName":"White_Marubozu"})
collection.insert_one({"PWay":"CandleStick","PName":"Bullish_Engulfing"})
collection.insert_one({"PWay":"CandleStick","PName":"Bullish_Harami"})
collection.insert_one({"PWay":"CandleStick","PName":"On_Neck"})
collection.insert_one({"PWay":"CandleStick","PName":"Hanging_Man"})
collection.insert_one({"PWay":"CandleStick","PName":"Bearish_Engulfing"})
collection.insert_one({"PWay":"CandleStick","PName":"Dark_Cloud"})
collection.insert_one({"PWay":"CandleStick","PName":"Morning_Star"})
collection.insert_one({"PWay":"CandleStick","PName":"Evening_Star"})
collection.insert_one({"PWay":"CandleStick","PName":"Three_Black_Crows"})
collection.insert_one({"PWay":"CandleStick","PName":"Black_Marubozu"})
collection.insert_one({"PWay":"CandleStick","PName":"Three_Inside_Down"})
collection.insert_one({"PWay":"CandleStick","PName":"Bearish_Harami"})
collection.insert_one({"PWay":"CandleStick","PName":"Tweezer_Top"})
collection.insert_one({"PWay":"CandleStick","PName":"Tweezer_Bottom"})
collection.insert_one({"PWay":"CandleStick","PName":"Three_Outside_Down"})
collection.insert_one({"PWay":"CandleStick","PName":"Shooting_Star"})
collection.insert_one({"PWay":"CandleStick","PName":"Hammer"})
collection.insert_one({"PWay":"CandleStick","PName":"Doji"})
collection.insert_one({"PWay":"CandleStick","PName":"Three_White_Soldiers"})

collection.insert_one({"PWay":"Charting","PName":"Rectangle_Bottom"})
collection.insert_one({"PWay":"Charting","PName":"Inverse_Head_And_Shoulders"})
collection.insert_one({"PWay":"Charting","PName":"Triangle_Top"})
collection.insert_one({"PWay":"Charting","PName":"Head_And_Shoulders"})
collection.insert_one({"PWay":"Charting","PName":"Rectangle_Top"})
collection.insert_one({"PWay":"Charting","PName":"Triangle_Bottom"})
collection.insert_one({"PWay":"Charting","PName":"Broadening_Bottom"})
collection.insert_one({"PWay":"Charting","PName":"Broadening_Top"})
collection.insert_one({"PWay":"Charting","PName":"Cup_And_Handle"})
collection.insert_one({"PWay":"Charting","PName":"Double_Top"})
collection.insert_one({"PWay":"Charting","PName":"Double_Bottom"})
collection.insert_one({"PWay":"Charting","PName":"Pennant_Flag"})




